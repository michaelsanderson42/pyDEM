This directory contains binary builds of TauDEM for several platforms. These
are provided as-is as a convenience and to help avoid incompatibilities with
versions of TauDEM, or different builds of TauDEM that may have been compiled
with different compile-time options. They have not been customized or
altered by Creare.

They are provided as-is and without any warranty, and are not covered by the
same license terms as the rest of the pyDEM package. Please see the packages
themselves, or the TauDEM website (http://hydrology.usu.edu/taudem/), for
more information on the terms of TauDEM's distribution.

